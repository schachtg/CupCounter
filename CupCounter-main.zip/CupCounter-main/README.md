# Cup Counter
A service to analyze live feeds and provide alerts when excessive alcohol consumption is found.
